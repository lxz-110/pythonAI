import math
import tkinter as tk
import form as form
import numpy as np

#神经网络
def tanh(x):
    return np.tanh(x)


def softmax(x):
    exp = np.exp(x - x.max())
    return exp / exp.sum()


dimes = [280 * 280, 10]
activation = [tanh, softmax]
distutils = [
    {'b': [0, 0]},
    {'b': [0, 0], 'w': [-math.sqrt(6 / (dimes[0] + dimes[1])), math.sqrt(6 / (dimes[0] + dimes[1]))]},
]


def init_parameters_b(layer):
    dist = distutils[layer]['b']
    return np.random.rand(dimes[layer]) * (dist[1] - dist[0]) + dist[0]


def init_parameters_w(layer):
    dist = distutils[layer]['w']
    return np.random.rand(dimes[layer - 1], dimes[layer]) * (dist[1] - dist[0]) + dist[0]


def init_parameters():
    parameters = []
    for i in range(len(distutils)):
        layer_parameters = {}
        for j in distutils[i].keys():
            if j == 'b':
                layer_parameters['b'] = init_parameters_b(i)
            elif j == 'w':
                layer_parameters['w'] = init_parameters_w(i)
        parameters.append(layer_parameters)
    return parameters


parameters = np.load("../model_parameters.npy", allow_pickle=True)

def predict(img, parameters):
    I0_in = img + parameters[0]['b']
    I0_out = activation[0](I0_in)
    I1_in = np.dot(I0_out, parameters[1]['w']) + parameters[1]['b']
    I1_out = activation[1](I1_in)
    return I1_out

def clear_canvas():
    canvas.delete("all")

def paint(event):
    x1, y1 = (event.x, event.y)
    x2, y2 = (event.x + 20, event.y + 20)
    canvas.create_oval(x1, y1, x2, y2, fill="white", outline="white")

def predict_image():
    # 获取画布上的图像数据
    image_data = []  # 存储图像数据的列表
    for y in range(280):
        for x in range(280):
            pixel_color = canvas.itemcget(canvas.find_closest(x, y), 'fill')
            # 如果颜色为白色，将像素值设为1；否则设为0
            if pixel_color == "white":
                image_data.append(1)
            else:
                image_data.append(0)

    # 将图像数据重塑为长度为 784 的一维数组
    img = np.array(image_data)

    # 重新初始化神经网络参数
    parameters = init_parameters()

    # 使用神经网络进行预测
    prediction = predict(img, parameters)

    # 输出预测结果
    print("预测结果:", prediction)
    print("最大值索引:", prediction.argmax())



# 创建主窗口
root = tk.Tk()
root.title("绘制数字")

# 创建画板
canvas = tk.Canvas(root, width=280, height=280, bg="black")
canvas.pack()

# 创建清除按钮
clear_button = tk.Button(root, text="清除全部", command=clear_canvas)
clear_button.pack()

# 创建确定按钮
predict_button = tk.Button(root, text="确定", command=predict_image)
predict_button.pack()

# 绑定鼠标事件
canvas.bind("<B1-Motion>", paint)

# 运行主循环
root.mainloop()
